import { startWorkers } from "../src/utils/queue.js";

startWorkers();
