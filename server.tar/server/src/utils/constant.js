const status = {
  Pending: "Pending",
  Completed: "Completed",
  Served: "Served",
};

export default status;
