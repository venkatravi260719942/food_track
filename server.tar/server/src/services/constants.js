const stockCapacity = {
  LOW_STOCK: "lowStock",
  CRITICAL_STOCK: "criticalStock",
  OUT_OF_STOCK: "outofStock",
};

export { stockCapacity };
