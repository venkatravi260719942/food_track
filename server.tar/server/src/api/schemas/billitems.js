export default {
  type: 'object',
  properties: {
    billId: { type: 'integer' },
    orderItemId: { type: 'integer' },
    amount: { type: 'integer' },
  },
  required: [
  ],
  additionalProperties: false,
};
