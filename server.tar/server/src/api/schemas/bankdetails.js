export default {
  type: "object",
  properties: {
    supplierId: { type: "integer" },
    bankDetail: { type: "string" },
  },
  required: [],
  additionalProperties: false,
};
