export default {
  type: "object",
  properties: {
    categoryId: { type: "integer" },
    categoryName: { type: "string" },
  },
  required: [],
  additionalProperties: false,
};
